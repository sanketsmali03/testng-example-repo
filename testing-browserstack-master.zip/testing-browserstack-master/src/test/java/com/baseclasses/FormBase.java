package com.baseclasses;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.*;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import java.time.Duration;

public class FormBase extends CodeBase {
        SoftAssert softAssert = new SoftAssert();

        public void EnterFirstName() {
                //String select = Keys.chord(Keys.COMMAND, Keys.CONTROL, "a");
                //String select = Keys.chord(Keys.SHIFT, Keys.ARROW_UP);
                String b = Keys.BACK_SPACE.toString();
                CharSequence select = StringUtils.repeat(b, 51);


                // Ensure that you can find the firstname element
                WebElement FirstName = driver.get().findElement(By.name("firstname"));
                boolean FirstNameVisible = FirstName.isDisplayed();
                softAssert.assertTrue(FirstNameVisible);
                //click into the box, send a blank value and then click anywhere on the field, check the error message shows
                FirstName.sendKeys("");
                new WebDriverWait(driver.get(), Duration.ofSeconds(10)).until(ExpectedConditions.elementToBeClickable(FirstName)).click();
                FirstName.click();
                FirstName.sendKeys(Keys.TAB);
                // WebElement blanket = driver.get().findElement(By.xpath("//html"));
                ////blanket.click();


                WebElement FirstNameError = driver.get().findElement(By.xpath("//span[contains(text(), 'Please enter a first name')]"));
                boolean FirstNameBlankErrorVisible = FirstNameError.isDisplayed();
                softAssert.assertTrue(FirstNameBlankErrorVisible);

                // Send numbers into FirstName, and then check that the proper error messages are displayed.
                FirstName.sendKeys("123");
                FirstName.sendKeys(Keys.TAB);
                ////blanket.click();

                // FirstName.click();
                WebElement FirstNameNumbers = driver.get().findElement(By.xpath("//span[contains(text(), 'Please enter a valid first name')]"));
                boolean FirstNameNumbersErrorVisible = FirstNameNumbers.isDisplayed();
                softAssert.assertTrue(FirstNameNumbersErrorVisible);
                FirstName.clear();

                FirstName.sendKeys(select);
                FirstName.sendKeys(Keys.DELETE);

                // Send special characters into FirstName, and then check that the proper error messages are displayed.
                FirstName.sendKeys("%<$£!");
                FirstName.sendKeys(Keys.TAB);
                ////blanket.click();


                WebElement FirstNameSpecial = driver.get().findElement(By.xpath("//span[contains(text(), 'Please enter a valid first name')]"));
                boolean FirstNameSpecialErrorVisible = FirstNameSpecial.isDisplayed();
                softAssert.assertTrue(FirstNameSpecialErrorVisible);
                FirstName.clear();

                FirstName.sendKeys(select);
                FirstName.sendKeys(Keys.DELETE);

                // Send 51 keys into the First Name field, and check that the proper error message is displayed, then clear down the box.
                FirstName.sendKeys(StringUtils.repeat("a", 51));
                FirstName.sendKeys(Keys.TAB);

                // FirstName.click();
                System.out.println("51 Keys have been input");

                WebElement FiftyOneKeys = driver.get().findElement(By.xpath("//span[contains(text(), 'First name cannot be longer than 50 characters')]"));
                boolean FiftyOneKeysErrorVisible = FiftyOneKeys.isDisplayed();
                softAssert.assertTrue(FiftyOneKeysErrorVisible);
                FirstName.sendKeys(select);
                FirstName.sendKeys(Keys.DELETE);
                FirstName.sendKeys("ABC1");
                FirstName.sendKeys(select);
                FirstName.sendKeys(Keys.DELETE);

                FirstName.sendKeys("Test");
                FirstName.sendKeys(Keys.TAB);

                // FirstName.click();

                softAssert.assertAll();
        }

        public void EnterSurname() {
                //String select = Keys.chord(Keys.COMMAND, Keys.CONTROL, "a");
                String b = Keys.BACK_SPACE.toString();
              //  CharSequence select = b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b;
                CharSequence select = StringUtils.repeat(b, 51);

                // Ensure that you can find the lastname element
                WebElement SecondName = driver.get().findElement(By.name("lastname"));
                boolean SecondNameVisible = SecondName.isDisplayed();
                softAssert.assertTrue(SecondNameVisible);
                //click into the box, send a blank value and then click anywhere on the field, check the error message shows
                SecondName.sendKeys("");
                SecondName.sendKeys(Keys.TAB);
                // WebElement blanket = driver.get().findElement(By.xpath("//html"));
                ////blanket.click();

                SecondName.click();
                WebElement SecondNameError = driver.get().findElement(By.xpath("//span[contains(text(), 'Please enter a last name')]"));
                boolean SecondNameBlankErrorVisible = SecondNameError.isDisplayed();
                softAssert.assertTrue(SecondNameBlankErrorVisible);

                // Send numbers into FirstName, and then check that the proper error messages are displayed.
                SecondName.sendKeys("123");
                SecondName.sendKeys(Keys.TAB);
                ////blanket.click();

                // SecondName.click();
                WebElement SecondNameNumbers = driver.get().findElement(By.xpath("//span[contains(text(), 'Please enter a valid last name')]"));
                boolean SecondNameNumbersErrorVisible = SecondNameNumbers.isDisplayed();
                softAssert.assertTrue(SecondNameNumbersErrorVisible);
                SecondName.sendKeys(select);
                SecondName.sendKeys(Keys.DELETE);

                // Send special characters into SecondName, and then check that the proper error messages are displayed.
                SecondName.sendKeys("%<$£!");
                SecondName.sendKeys(Keys.TAB);
                ////blanket.click();

                // SecondName.click();
                WebElement SecondNameSpecial = driver.get().findElement(By.xpath("//span[contains(text(), 'Please enter a valid last name')]"));
                boolean SecondNameSpecialErrorVisible = SecondNameSpecial.isDisplayed();
                softAssert.assertTrue(SecondNameSpecialErrorVisible);
                SecondName.clear();

                SecondName.sendKeys(select);
                SecondName.sendKeys(Keys.DELETE);

                // Send 51 keys into the Second Name field, and check that the proper error message is displayed, then clear down the box.
                SecondName.sendKeys(StringUtils.repeat("a", 51));
                SecondName.sendKeys(Keys.TAB);
                System.out.println("51 Keys have been input");
                WebElement FiftyOneKeys = driver.get().findElement(By.xpath("//span[contains(text(), 'Last name cannot be longer than 50 characters')]"));
                boolean FiftyOneKeysErrorVisible = FiftyOneKeys.isDisplayed();
                softAssert.assertTrue(FiftyOneKeysErrorVisible);
                SecondName.sendKeys(select);
                SecondName.sendKeys(Keys.DELETE);

                SecondName.sendKeys("ABC1");
                SecondName.sendKeys(Keys.TAB);

                // SecondName.click();
                SecondName.sendKeys(select);
                SecondName.sendKeys(Keys.DELETE);

                SecondName.sendKeys("AutomatedTest");
                SecondName.sendKeys(Keys.TAB);

                //SecondName.click();

                softAssert.assertAll();
        }

        public void EnterEmail() {
                // Create a string that contains the action "Control + A" on a keyboard
                // String select = Keys.chord(Keys.COMMAND, Keys.CONTROL, "a");
                String b = Keys.BACK_SPACE.toString();
                //CharSequence select = b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b;
                CharSequence select = StringUtils.repeat(b, 51);

                WebElement blanket = driver.get().findElement(By.xpath("//html"));

                // Ensure that you can find the email element
                WebElement email = driver.get().findElement(By.name("email"));
                boolean emailVisible = email.isDisplayed();
                softAssert.assertTrue(emailVisible);
                //click into the box, send a blank value and then click anywhere on the field, check the error message shows
                email.sendKeys("");
                email.click();
                email.sendKeys(Keys.TAB);
                //blanket.click();
                WebElement EmailBlankError = driver.get().findElement(By.xpath("//*[contains(text(), 'Please enter an email address')]"));
                boolean emailBlankErrorVisible = EmailBlankError.isDisplayed();
                softAssert.assertTrue(emailBlankErrorVisible);
                // Send 101 keys into the First Name field, and check that the proper error message is displayed, then clear down the box.
                email.sendKeys(StringUtils.repeat("a", 101));
                email.sendKeys(Keys.TAB);
                System.out.println("101 keys have been input in the email field");
                //blanket.click();
                WebElement OneohOneKeysError = driver.get().findElement(By.xpath("//*[contains(text(),'Email address cannot be longer than 100 characters')]"));
                boolean OneohOneKeysErrorVisible = OneohOneKeysError.isDisplayed();
                softAssert.assertTrue(OneohOneKeysErrorVisible);
                //Enter an invalid email into the email field and ensure that the correct error message displays
                email.sendKeys(select);
                email.sendKeys(Keys.DELETE);
                email.sendKeys("test@test@gmail.com");
                email.sendKeys(Keys.TAB);
                WebElement EmailInvalidError = driver.get().findElement(By.xpath("//*[contains(text(), 'Please enter a valid email address')]"));
                boolean emailInvalidErrorVisible = EmailInvalidError.isDisplayed();
                softAssert.assertTrue(emailInvalidErrorVisible);
                String emailInvalidErrorText = EmailInvalidError.getText();
                softAssert.assertEquals(emailInvalidErrorText, "Please enter a valid email address");

                email.sendKeys(select);
                email.sendKeys(Keys.DELETE);
                email.sendKeys("test@gmail.com");
                email.sendKeys(Keys.TAB);
                softAssert.assertAll();
        }

        public void Fill_in_ContactField() {
                // Create a string that contains the action "Control + A" on a keyboard
                //String select = Keys.chord(Keys.COMMAND, Keys.CONTROL, "a");
                String b = Keys.BACK_SPACE.toString();
              //  CharSequence select = b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b;
                CharSequence select = StringUtils.repeat(b, 51);

                WebElement blanket = driver.get().findElement(By.xpath("//html"));

                // Ensure that you can find the contactNumber field
                WebElement contactNum = driver.get().findElement(By.name("contactNumber"));
                boolean contactNumVisible = contactNum.isDisplayed();
                softAssert.assertTrue(contactNumVisible);

                contactNum.sendKeys("$£%&");
                contactNum.click();
                contactNum.sendKeys(Keys.TAB);
                //blanket.click();
                WebElement contactNumError = driver.get().findElement(By.xpath("//*[contains(text(), 'Please enter a valid contact number')]"));
                boolean contactNumErrorVisible = contactNumError.isDisplayed();
                softAssert.assertTrue(contactNumErrorVisible);

                contactNum.sendKeys("-441234567890");
                contactNum.sendKeys(Keys.TAB);
                //blanket.click();
                softAssert.assertTrue(contactNumErrorVisible);
                contactNum.sendKeys(select);
                contactNum.sendKeys(Keys.DELETE);

                contactNum.sendKeys("+5941234567890");
                //blanket.click();
                contactNum.getCssValue("class");
                softAssert.assertTrue(contactNumErrorVisible);
                contactNum.sendKeys(select);
                contactNum.sendKeys(Keys.DELETE);

                contactNum.sendKeys("+911234567890");
                contactNum.sendKeys(Keys.TAB);
                //blanket.click();
                String caseVal = contactNum.getAttribute("class");
                System.out.println("Printing contact number error " + caseVal);

                softAssert.assertEquals(caseVal, "FormControl__input FormControl__input--valid", "Printing for 911234567890");
                contactNum.sendKeys(select);
                contactNum.sendKeys(Keys.DELETE);

                contactNum.sendKeys("+447777777777");
                contactNum.sendKeys(Keys.TAB);
                //blanket.click();
                softAssert.assertEquals(caseVal, "FormControl__input FormControl__input--valid", "printing for +447777777777");

                contactNum.sendKeys(select);
                contactNum.sendKeys(Keys.DELETE);

                contactNum.sendKeys("1234567890");
                contactNum.sendKeys(Keys.TAB);
                //blanket.click();
                softAssert.assertEquals(caseVal, "FormControl__input FormControl__input--valid", "Printing for1234567890");

                softAssert.assertAll();

        }

        public void Fill_In_PostCode() {
                // Create a string that contains the action "Control + A" on a keyboard
                //String select = Keys.chord(Keys.COMMAND, Keys.CONTROL, "a");

                String b = Keys.BACK_SPACE.toString();
               // CharSequence select = b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b;
                CharSequence select = StringUtils.repeat(b, 51);

                WebElement blanket = driver.get().findElement(By.xpath("//html"));

                // Ensure that you can find the postcodeber field
                WebElement postcode = driver.get().findElement(By.name("postcode"));
                boolean postcodeVisible = postcode.isDisplayed();
                softAssert.assertTrue(postcodeVisible);

                postcode.sendKeys("NE128ET");
                postcode.click();
                postcode.sendKeys(Keys.TAB);
                //blanket.click();
                String caseValid = postcode.getAttribute("class");
                softAssert.assertEquals(caseValid, "FormControl__input FormControl__input--valid");
                postcode.sendKeys(select);
                postcode.sendKeys(Keys.DELETE);

                postcode.sendKeys("123 456");
                postcode.sendKeys(Keys.TAB);
                //blanket.click();
                String caseInvalid = postcode.getAttribute("class");
                softAssert.assertEquals(caseInvalid, "FormControl__input FormControl__input--invalid");
                WebElement postcodeError = driver.get().findElement(By.xpath("//*[contains(text(), 'Please enter a valid postcode')]"));
                boolean postcodeErrorVisible = postcodeError.isDisplayed();
                softAssert.assertTrue(postcodeErrorVisible);
                postcode.sendKeys(select);
                postcode.sendKeys(Keys.DELETE);

                postcode.sendKeys("TEST");
                postcode.sendKeys(Keys.TAB);
                //blanket.click();
                softAssert.assertEquals(caseInvalid, "FormControl__input FormControl__input--invalid");
                softAssert.assertTrue(postcodeErrorVisible);
                postcode.sendKeys(select);
                postcode.sendKeys(Keys.DELETE);

                postcode.sendKeys("%$£!@");
                postcode.sendKeys(Keys.TAB);
                //blanket.click();
                softAssert.assertEquals(caseInvalid, "FormControl__input FormControl__input--invalid");
                softAssert.assertTrue(postcodeErrorVisible);
                postcode.sendKeys(select);
                postcode.sendKeys(Keys.DELETE);
                postcode.sendKeys("NE12 8ET");
                postcode.sendKeys(Keys.TAB);

                softAssert.assertAll();
        }

        public void FilterThroughDropdowns() {

                // Create a string that contains the action "Control + A" on a keyboard
                //String select = Keys.chord(Keys.COMMAND, Keys.CONTROL, "a");
                String b = Keys.BACK_SPACE.toString();
               // CharSequence select = b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b + b;

                CharSequence select = StringUtils.repeat(b, 51);


                WebElement blanket = driver.get().findElement(By.xpath("//html"));

                // Ensure that you can find the postcodeber field
                WebElement hearAboutUs = driver.get().findElement(By.xpath("//span/select"));
                boolean hearAboutUsVisible = hearAboutUs.isDisplayed();
                softAssert.assertTrue(hearAboutUsVisible);

                JavascriptExecutor js = (JavascriptExecutor) driver.get();
                Select dropdown = new Select(driver.get().findElement(By.xpath("//span/select")));
                int NoOfDropdowns = dropdown.getOptions().size() - 1;
                WebElement firstOption = dropdown.getFirstSelectedOption();
                String firstOptionText = firstOption.getText();
                System.out.println("Printing the first select option firstOptionText " + firstOptionText);
                Assert.assertEquals(firstOptionText, "Please select an option");
                System.out.println("clicking on hear bout us");
                //hearAboutUs.click();
                js.executeScript("browserstack_executor: {\"action\": \"annotate\", \"arguments\": {\"data\": \"clicked on hear about us\", \"level\": \"info\"}}");
                System.out.println("clicked on option");

                Wait<WebDriver> wait = new FluentWait<WebDriver>(driver.get()).withTimeout(Duration.ofSeconds(60)).pollingEvery(Duration.ofSeconds(1));
                WebElement getBackToMe = driver.get().findElement(By.xpath("//button/span[contains(text(),'Get back to me')]"));
                System.out.println("getBackToMeTest" + getBackToMe);
                js.executeScript("arguments[0].scrollIntoView();", getBackToMe);
                wait.until(ExpectedConditions.elementToBeClickable(driver.get().findElement(By.xpath("//button/span[contains(text(),'Get back to me')]"))));
                // getBackToMe.click();
                js.executeScript("arguments[0].click();", getBackToMe);
                System.out.println("Clicked on get Back to me ");

              /*  System.out.println("scrolling to top");
                Select drpCountry = new Select(driver.get().findElement(By.name("whereDidYouHearAboutUs")));
                drpCountry.selectByVisibleText("Facebook");
                String item = "Facebook";*/
                Select drpCountry = new Select(driver.get().findElement(By.name("whereDidYouHearAboutUs")));

                String item = "Facebook";

                js.executeScript("const textToFind = '" + item + "';" +
                        "const dd = arguments[0];" +
                        "dd.selectedIndex = [...dd.options].findIndex (option => option.text === textToFind);", drpCountry);


                System.out.println("select completed");


           /*     System.out.println("scrolling to hear about us");
                 wait = new WebDriverWait(driver.get(), Duration.ofSeconds(30));
                wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(), 'Please select a valid option')]")));
                WebElement dropdownError = driver.get().findElement(By.xpath("//span[contains(text(), 'Please select a valid option')]"));
                js.executeScript("arguments[0].scrollIntoView();", dropdownError);
                boolean dropdownErrorVisible = dropdownError.isDisplayed();
                softAssert.assertTrue(dropdownErrorVisible);

                dropdownError.click();
                softAssert.assertEquals(dropdownError.getText(), "Please select a valid option for where you heard about us");
                for (int i = 1; i < NoOfDropdowns; i++) {
                        dropdown.selectByIndex(i);
                }

                System.out.println("End of dropdown select");*/


                softAssert.assertAll();
        }

        public void Check_Checkboxes() {
                WebElement getMoreInformation = driver.get().findElement(By.xpath("//*[contains(text(),'Get more information')]"));
                boolean getMoreInformationDisplayed = getMoreInformation.isDisplayed();
                softAssert.assertTrue(getMoreInformationDisplayed);
                getMoreInformation.click();

                WebElement arrangeAVisit = driver.get().findElement(By.xpath("//*[contains(text(), 'Arrange a visit')]"));
                boolean arrangeAVisitVisible = arrangeAVisit.isDisplayed();
                softAssert.assertTrue(arrangeAVisitVisible);
                arrangeAVisit.click();

                WebElement requestACallback = driver.get().findElement(By.xpath("//*[contains(text(),'Request a callback')]"));
                boolean requestACallbackVisible = requestACallback.isDisplayed();
                softAssert.assertTrue(requestACallbackVisible);
                requestACallback.click();

                softAssert.assertAll();
        }

        public void Click_Declaration() {
                //Define by locating the "declaring my interest" button
                WebElement declaration = driver.get().findElement(By.cssSelector(".FormCheck__tick.FormCheck__tick--small-dark-rounded"));
                //Check to make sure that the declaration is visible
                boolean declarationVisible = declaration.isDisplayed();
                softAssert.assertTrue(declarationVisible);
                //click into the button twice, in order to produce the error message for it not being ticked.
                declaration.click();
                //locate & define the error message
                //  WebElement declarationError = driver.get().findElement(By.xpath("//*[@class='FormError']"));
                //verify the error message is present (button is unchecked)
                //  boolean declarationErrorVisible = declarationError.isDisplayed();
                //  softAssert.assertTrue(declarationErrorVisible);
                //click to turn on the button
                //    declaration.click();
                softAssert.assertAll();
        }

        public void Click_Get_Back_To_Me() {
                WebElement getBackToMe = driver.get().findElement(By.xpath("//span[contains(text(), 'Get back to me')]"));
                boolean getBackToMeVisible = getBackToMe.isDisplayed();
                softAssert.assertTrue(getBackToMeVisible);
//            comment the below out to not flood the site
//            getBackToMe.click();
//            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
//            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[contains(text(), 'Your enquiry was successful')]")));
                softAssert.assertAll();
        }
}



