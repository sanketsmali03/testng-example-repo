package com.baseclasses;


import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.safari.SafariDriver;
import org.testng.annotations.*;
import java.time.Duration;
import io.github.bonigarcia.wdm.WebDriverManager;

public class CookiesBase {


    // public WebDriver driver;
    protected static ThreadLocal<WebDriver> driver = new ThreadLocal<>();


    @BeforeClass(alwaysRun = true)
    @SuppressWarnings("unchecked")
    public void setUp() throws Exception {
        ChromeOptions options = new ChromeOptions();
        options.addArguments("start-maximized");
        DesiredCapabilities capabilities = new DesiredCapabilities();
        capabilities.setCapability(ChromeOptions.CAPABILITY, options);
        capabilities.setCapability("nativeWebTap","true");
        driver.set(new ChromeDriver(options));
        driver.get().get("http://yourpersonahome.com");
        driver.get().manage().timeouts().pageLoadTimeout(Duration.ofSeconds(10));
        driver.get().manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        System.out.println("Launching the main website " + driver.get().getTitle());

    }

    @AfterClass(alwaysRun = true)
    public void tearDown() throws Exception {
        if (driver.get() != null) {
            driver.get().quit();
        }
    }
}

