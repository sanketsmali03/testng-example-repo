package com.baseclasses;


import org.openqa.selenium.WebElement;

import org.testng.asserts.SoftAssert;
import org.openqa.selenium.support.Color;


public class ColorBase extends CodeBase{

    public void verify_color_black(WebElement black) {
        SoftAssert softAssert = new SoftAssert();
        String color1 = black.getCssValue("color");
        String tmpHexColour = Color.fromString(color1).asHex();
        softAssert.assertEquals(tmpHexColour, "#383737");
        System.out.println("color code  is  #383737");
        softAssert.assertAll();
    }

    public void verify_color_white(WebElement white) {
        SoftAssert softAssert = new SoftAssert();
        String color1 = white.getCssValue("color");
        String tmpHexColour = Color.fromString(color1).asHex();
        softAssert.assertEquals(tmpHexColour, "#ffffff");
        System.out.println("color code  is  #ffffff");
        softAssert.assertAll();
    }

    public void verify_color_teal(WebElement teal) {
        SoftAssert softAssert = new SoftAssert();
        String color1 = teal.getCssValue("color");
        String tmpHexColour = Color.fromString(color1).asHex();
        softAssert.assertEquals(tmpHexColour, "#64c2c8");
        System.out.println("color code  is  #64c2c8");
        softAssert.assertAll();
    }


    public void verify_color_other_one(WebElement other) {
        SoftAssert softAssert = new SoftAssert();
        String color1 = other.getCssValue("color");
        String tmpHexColour = Color.fromString(color1).asHex();
        softAssert.assertEquals(tmpHexColour, "#184042");
        System.out.println("color code  is  #184042");
        softAssert.assertAll();
    }
    //expected
    public void verify_color_grey(WebElement grey) {
        SoftAssert softAssert = new SoftAssert();
        String color1 = grey.getCssValue("color");
        String tmpHexColour = Color.fromString(color1).asHex();
        System.out.println("Value of tmpHexColour "+tmpHexColour);
        softAssert.assertEquals(tmpHexColour, "#1d242c");
        System.out.println("color code  is  #1d242c");
        softAssert.assertAll();
    }


    public void verify_bgcolor_black(WebElement black) {
        SoftAssert softAssert = new SoftAssert();
        String color1 = black.getCssValue("background-color");
        String tmpHexColour = Color.fromString(color1).asHex();
        softAssert.assertEquals(tmpHexColour, "#383737");;
        System.out.println("color code  is  #383737");
        softAssert.assertAll();
    }

    public void verify_bgcolor_white(WebElement white) {
        SoftAssert softAssert = new SoftAssert();
        String color1 = white.getCssValue("background-color");
        String tmpHexColour = Color.fromString(color1).asHex();
        softAssert.assertEquals(tmpHexColour, "#ffffff");
        System.out.println("color code  is  #ffffff");
        softAssert.assertAll();
    }

    public void verify_bgcolor_teal(WebElement teal) {
        SoftAssert softAssert = new SoftAssert();
        String color1 = teal.getCssValue("background-color");
        String tmpHexColour = Color.fromString(color1).asHex();
        softAssert.assertEquals(tmpHexColour, "#64c2c8");
        System.out.println("color code  is  #64c2c8");
        softAssert.assertAll();
    }

    public void verify_color_dark_icon(WebElement other) {
        SoftAssert softAssert = new SoftAssert();
        String color1 = other.getCssValue("color");
        String tmpHexColour = Color.fromString(color1).asHex();
        softAssert.assertEquals(tmpHexColour, "#4da6ac");
        System.out.println("color code is #4da6ac");
        softAssert.assertAll();
    }

}


