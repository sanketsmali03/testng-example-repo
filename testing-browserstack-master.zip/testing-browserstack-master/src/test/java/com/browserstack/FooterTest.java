package com.browserstack;

import com.baseclasses.FooterBase;
import org.openqa.selenium.*;
import org.testng.annotations.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.asserts.SoftAssert;

import java.time.Duration;
import java.util.Iterator;
import java.util.Set;


public class FooterTest extends FooterBase {
    SoftAssert softAssert = new SoftAssert();
    FooterBase footer = new FooterBase();

    @Test(priority = 1)
    public void Scroll_to_footer_section_and_verify_all_the_sections_are_displayed() {
        WebElement footersection = driver.get().findElement(By.xpath("//*[@class=\"Section Section--main Footer__section\"]"));
        //A) verifying footer section is present
        softAssert.assertTrue(footersection.isDisplayed());
        WebElement footertextcontactusele = driver.get().findElement(By.xpath("(//*[@class='h4 Footer__nav-title'])[1]"));
        String footertextcontactus = footertextcontactusele.getText();
        //B) verify the footer is divided in 3 sections Contact Us, Legal Stuff and Get In Touch
        softAssert.assertEquals("Contact us", footertextcontactus);
        WebElement legalstuffEle = driver.get().findElement(By.xpath("(//*[@class='h4 Footer__nav-title'])[2]"));
        String legalstuffText = legalstuffEle.getText();
        softAssert.assertEquals("Legal stuff", legalstuffText);
        WebElement getintouchEle = driver.get().findElement(By.xpath("(//*[@class='h4 Footer__nav-title'])[3]"));
        String getintouchText = getintouchEle.getText();
        softAssert.assertEquals("Get in touch", getintouchText);
        softAssert.assertAll();
    }

    @Test(priority = 2)
    public void Scroll_to_footer_section_and_verify_the_contact_us_section() throws InterruptedException {
        Actions actions = new Actions(driver.get());
        WebElement meetoursalesEle = driver.get().findElement(By.xpath("(//*[@class='Nav__link Footer__nav-link'])[1]"));
        String meetoursalesText = meetoursalesEle.getText();
        //verify the meet our sales text is correct
        softAssert.assertEquals(meetoursalesText, "Meet our sales hosts dedicated to each of our developments.");
        verify_color_grey(meetoursalesEle);
        ((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView();", meetoursalesEle);
        //hover over the link
        actions.moveToElement(meetoursalesEle).build().perform();
        //actions.moveToElement(meetoursalesEle).perform();
        Thread.sleep(2000);
        verify_color_teal(meetoursalesEle);
        //verify the color of the text before and after hovering
        meetoursalesEle.click();
        Thread.sleep(2000);
        String currentURL = driver.get().getCurrentUrl();
        //verify the user is on get in touch page
        softAssert.assertEquals(currentURL, "https://ppt.yourpersonahome.com/get-in-touch");
        driver.get().navigate().back();
        softAssert.assertAll();
    }

    @Test(priority = 3)
    public void Scroll_to_footer_section_and_verify_the_legal_stuff_section() throws InterruptedException {
        Actions actions = new Actions(driver.get());
        //verify the sections in the legal stuff
        footer.test_the_footer_section_and_the_legal_stuff_section();
        WebElement tandcEle = driver.get().findElement(By.xpath("(//*[@class='Nav__link Footer__nav-link'])[2]"));
        String tandcEleText = tandcEle.getText();
        //verify the terms and conditions text is correct
        softAssert.assertEquals(tandcEleText, "Persona terms & conditions");
        verify_color_grey(tandcEle);
        ((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView();", tandcEle);
        actions.moveToElement(tandcEle).perform();
        Thread.sleep(2000);
        verify_color_teal(tandcEle);
        tandcEle.click();
        Thread.sleep(2000);
        String currentURL = driver.get().getCurrentUrl();
        //verify the user is on terms and conditions page
        softAssert.assertEquals(currentURL, "https://ppt.yourpersonahome.com/legal/terms-and-conditions");
        driver.get().navigate().back();
        WebElement cookiepolicyEle = driver.get().findElement(By.xpath("(//*[@class='Nav__link Footer__nav-link'])[3]"));
        String cookiepolicyText = cookiepolicyEle.getText();
        //verify the cookie policy text is correct
        softAssert.assertEquals(cookiepolicyText, "Cookie policy");
        verify_color_grey(cookiepolicyEle);
        ((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView();", cookiepolicyEle);
        actions.moveToElement(cookiepolicyEle).perform();
        Thread.sleep(2000);
        verify_color_teal(cookiepolicyEle);
        cookiepolicyEle.click();
        Thread.sleep(2000);
        String currentURL1 = driver.get().getCurrentUrl();
        //verify the user is on cookie policy page
        softAssert.assertEquals(currentURL1, "https://ppt.yourpersonahome.com/legal/cookie-policy");
        driver.get().navigate().back();
        WebElement privacypolicyEle = driver.get().findElement(By.xpath("(//*[@class='Nav__link Footer__nav-link'])[4]"));
        String privacypolicyText = privacypolicyEle.getText();
        //verify the privacy policy text is correct
        softAssert.assertEquals(privacypolicyText, "Privacy policy");
        verify_color_grey(privacypolicyEle);
        ((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView();", privacypolicyEle);
        actions.moveToElement(privacypolicyEle).perform();
        Thread.sleep(2000);
        verify_color_teal(privacypolicyEle);
        privacypolicyEle.click();
        Thread.sleep(2000);
        String currentURL2 = driver.get().getCurrentUrl();
        //verify the user is on privacy policy page
        softAssert.assertEquals(currentURL2, "https://ppt.yourpersonahome.com/legal/privacy-policy");
        driver.get().navigate().back();
        System.out.println(driver.get().getCurrentUrl());
        softAssert.assertAll();
    }
    @Test(priority = 4)
    public void Scroll_to_footer_section_and_verify_the_get_in_touch_section() throws InterruptedException {
        Actions actions = new Actions(driver.get());
        //verify the options in get in touch section
        footer.test_the_footer_section_and_the_get_in_touch_section();
        //verify the four icons
        footer.test_the_footer_section_and_the_four_icons();
        WebElement numberEle = driver.get().findElement(By.xpath("(//*[@class='Nav__link Nav__link--bold'])[1]"));
        verify_color_grey(numberEle);
        ((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView();", numberEle);
        actions.moveToElement(numberEle).perform();
        Thread.sleep(2000);
        verify_color_teal(numberEle);
        WebElement emailEle = driver.get().findElement(By.xpath("(//*[@class='Nav__link Nav__link--bold'])[2]"));
        verify_color_grey(emailEle);
        ((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView();", emailEle);
        actions.moveToElement(emailEle).perform();
        Thread.sleep(2000);
        verify_color_teal(emailEle);
        softAssert.assertAll();
    }

    @Test(priority = 5)
    public void verify_that_Email_has_been_auto_populated_correctly() {
        //print the href for contact us email
        WebElement contactus  = driver.get().findElement(By.xpath("(//*[@class='Nav__link Nav__link--bold'])[2]"));
        System.out.println(contactus.getAttribute("href"));
        String href3 = contactus.getAttribute("href");
        String href4 = href3.replaceAll("mailto:", "");
        String href5 = href4.substring(0,30);
        System.out.println("email is - " + href5);
//A) checking the email address it is going to
        softAssert.assertEquals(href5, "contactus@yourpersonahome.com?");
        String subject = href4.substring(30,69);
        String subject1 = subject.replaceAll("subject=", "");
        String subject2 = subject1.replaceAll("%20", " ");
        System.out.println("subject is - " + subject2);
//B) checking the subject of the contact us email
        softAssert.assertEquals(subject2, "Persona Homes Web Enquiry");
        String body = href4.substring(75,293);
        String actualbody =body.replaceAll("%20", " ");
        String actualbody1 =actualbody.replaceAll("%2C", " ");
//C) checking the body of the email
        softAssert.assertEquals(actualbody1, "If you are interested in a Persona home and would like us to help you find the home that suits you  please enter your details and we will get back to you.");
//D) checking the fields for firstname, lastname, contact number, email address, enquiry
        String href10 = href3.replaceAll("%20", " ");
        boolean surname = href10.contains("Surname");
        softAssert.assertTrue(surname);
        boolean fname = href10.contains("First name");
        softAssert.assertTrue(fname);
        boolean cnumber = href10.contains("Contact Number");
        softAssert.assertTrue(cnumber);
        boolean eaddress = href10.contains("Email Address");
        softAssert.assertTrue(eaddress);
        boolean enquiry = href10.contains("Enquiry");
        softAssert.assertTrue(enquiry);
        softAssert.assertAll();
    }

    @Test(priority = 6)
    public void Scroll_to_footer_section_and_verify_the_facebook_app_button() throws InterruptedException {

        SoftAssert softAssert = new SoftAssert();
        String parentWindow = driver.get().getWindowHandle();
        System.out.println("printing title of the page "+driver.get().getTitle());
        WebElement fbiconEle = driver.get().findElement(By.cssSelector("[href*='facebook']"));
        verify_color_teal(fbiconEle);
        JavascriptExecutor executor = (JavascriptExecutor)driver.get();
        executor.executeScript("arguments[0].scrollIntoView(true);", fbiconEle);

        Actions action = new Actions(driver.get());
        action.moveToElement(fbiconEle).perform();
        Thread.sleep(2000);
        verify_color_dark_icon(fbiconEle);

        executor.executeScript("arguments[0].click();", fbiconEle);

        Set<String> allWindowHandles = driver.get().getWindowHandles();
        System.out.println(driver.get().getWindowHandles().size());

        Iterator<String> it = allWindowHandles.iterator();
        while (it.hasNext()){
            String childWindow = it.next();

            if (!parentWindow.equals(childWindow)){
                driver.get().switchTo().window(childWindow);
                Thread.sleep(2000);
                System.out.println("Printing URL of child window    -    " +driver.get().getCurrentUrl());

                softAssert.assertEquals(driver.get().getCurrentUrl(),"https://www.facebook.com/yourpersonahome","facebook url return");
                driver.get().close();
            }
        }
        driver.get().switchTo().window(parentWindow);
        System.out.println("Printing title of parent window    -    "+driver.get().getTitle());
        softAssert.assertAll();
    }

    @Test(priority = 7)
    public void scroll_to_footer_section_and_verify_the_twitter_app_button() throws InterruptedException {
        SoftAssert softAssert = new SoftAssert();
        String parentWindow = driver.get().getWindowHandle();
        System.out.println("printing title of the page "+driver.get().getTitle());
        WebElement twiconEle = driver.get().findElement(By.cssSelector("[href*='twitter']"));

        verify_color_teal(twiconEle);
        JavascriptExecutor executor = (JavascriptExecutor)driver.get();
        executor.executeScript("arguments[0].scrollIntoView(true);", twiconEle);

        Actions action = new Actions(driver.get());
        action.moveToElement(twiconEle).perform();
        Thread.sleep(2000);
        verify_color_dark_icon(twiconEle);

        executor.executeScript("arguments[0].click();", twiconEle);

        Set<String> allWindowHandles = driver.get().getWindowHandles();
        System.out.println(driver.get().getWindowHandles().size());

        Iterator<String> it = allWindowHandles.iterator();
        while (it.hasNext()){
            String childWindow = it.next();

            if (!parentWindow.equals(childWindow)){

                driver.get().switchTo().window(childWindow);
                driver.get().manage().timeouts().implicitlyWait(Duration.ofSeconds(50));
                //Thread.sleep(2000);
                System.out.println("Printing URL of child window    -    " +driver.get().getCurrentUrl());
                softAssert.assertEquals(driver.get().getCurrentUrl(),"https://twitter.com/yourpersonahome","twitter url return");
                driver.get().close();
            }
        }
        driver.get().switchTo().window(parentWindow);
        System.out.println("Printing title of parent window    -    "+driver.get().getTitle());
        softAssert.assertAll();
    }

    @Test(priority = 8)
    public void scroll_to_footer_section_and_verify_the_instagram_app_button() throws InterruptedException {
        SoftAssert softAssert = new SoftAssert();
        String parentWindow = driver.get().getWindowHandle();
        System.out.println("printing title of the page "+driver.get().getTitle());
        WebElement igiconEle = driver.get().findElement(By.cssSelector("[href*='instagram']"));

        verify_color_teal(igiconEle);
        JavascriptExecutor executor = (JavascriptExecutor)driver.get();
        executor.executeScript("arguments[0].scrollIntoView(true);", igiconEle);

        Actions action = new Actions(driver.get());
        action.moveToElement(igiconEle).perform();
        Thread.sleep(2000);
        verify_color_dark_icon(igiconEle);

        executor.executeScript("arguments[0].click();", igiconEle);

        Set<String> allWindowHandles = driver.get().getWindowHandles();
        System.out.println(driver.get().getWindowHandles().size());

        Iterator<String> it = allWindowHandles.iterator();
        while (it.hasNext()){
            String childWindow = it.next();

            if (!parentWindow.equals(childWindow)){

                driver.get().switchTo().window(childWindow);
                driver.get().manage().timeouts().implicitlyWait(Duration.ofSeconds(50));
                //Thread.sleep(2000);
                System.out.println("Printing URL of child window    -    " +driver.get().getCurrentUrl());
                softAssert.assertEquals(driver.get().getCurrentUrl(),"https://www.instagram.com/yourpersonahome/","instagram url return");
                driver.get().close();
            }
        }
        driver.get().switchTo().window(parentWindow);
        System.out.println("Printing title of parent window    -    "+driver.get().getTitle());
        softAssert.assertAll();
    }

    @Test(priority = 9,dependsOnMethods = {})
    public void Scroll_to_footer_section_and_verify_the_linkedin_app_button() throws InterruptedException {
        SoftAssert softAssert = new SoftAssert();
        String parentWindow = driver.get().getWindowHandle();
        System.out.println("printing title of the page "+driver.get().getTitle());
        WebElement liiconEle = driver.get().findElement(By.cssSelector("[href*='linked']"));

        verify_color_teal(liiconEle);
        JavascriptExecutor executor = (JavascriptExecutor)driver.get();
        executor.executeScript("arguments[0].scrollIntoView(true);", liiconEle);

        Actions action = new Actions(driver.get());
        action.moveToElement(liiconEle).perform();
        Thread.sleep(2000);
        verify_color_dark_icon(liiconEle);

        executor.executeScript("arguments[0].click();", liiconEle);

        Set<String> allWindowHandles = driver.get().getWindowHandles();
        System.out.println(driver.get().getWindowHandles().size());

        Iterator<String> it = allWindowHandles.iterator();
        while (it.hasNext()){
            String childWindow = it.next();

            if (!parentWindow.equals(childWindow)){

                driver.get().switchTo().window(childWindow);
                driver.get().manage().timeouts().implicitlyWait(Duration.ofSeconds(50));
                //Thread.sleep(2000);
                String URLnew1 = driver.get().getCurrentUrl();
                System.out.println("Printing URL of child window    -    " +driver.get().getCurrentUrl());
                //checking the url opened contains linkedin
                String text = "https://www.linkedin.com/company/persona-homes";
                String bodyText = URLnew1;
                softAssert.assertTrue(bodyText.contains(text));
                driver.get().close();
            }
        }
        driver.get().switchTo().window(parentWindow);
        System.out.println("Printing title of parent window    -    "+driver.get().getTitle());
        softAssert.assertAll();
    }

    @Test (priority = 10)
    public void Go_to_footer_and_verify_each_element() {
        System.out.println("check footer on Get In Touch Page");
        footer.test_the_footer_section_the_text_and_the_copyright();
        footer.test_the_footer_section_and_the_contact_us_section();
        footer.test_the_footer_section_and_the_legal_stuff_section();
        footer.test_the_footer_section_and_the_get_in_touch_section();
        footer.test_the_footer_section_and_the_four_icons();
        System.out.println("footer verified");
        //softAssert.assertAll();
    }

}
 