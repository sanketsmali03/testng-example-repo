package com.browserstack;

import com.baseclasses.CookiesBase;
import org.openqa.selenium.By;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import com.baseclasses.CodeBase;
import java.time.Duration;
import java.util.Set;

public class AcceptCookiesTest extends CookiesBase {
    SoftAssert softAssert = new SoftAssert();
    @Test
    public void click_on_accept_cookies() throws InterruptedException {
        WebElement cookiebannerhEle = driver.get().findElement(By.xpath("//*[@class='CookieBanner__heading']"));
        String cookiebannerhText = cookiebannerhEle.getText();
        //verifying the cookie banner
        softAssert.assertEquals(cookiebannerhText, "We use cookies");
        WebElement cookiebannerEle = driver.get().findElement(By.xpath("//*[@class='CookieBanner__text']"));
        String cookiebannerText = cookiebannerEle.getText();
        //verifying the cookie banner subtext
        softAssert.assertEquals(cookiebannerText, "We use cookies to give you the best possible experience on our website. By continuing to browse this site, you give consent for cookies to be used. For more details, please read our Cookie Policy.");
        WebElement viewpBtnEle = driver.get().findElement(By.xpath("(//*[@class='Button Button--light CookieBanner__button'])[1]"));
        String viewpBtnText = viewpBtnEle.getText();
        //verifying the three buttons exist
        softAssert.assertEquals(viewpBtnText, "View policy");
        WebElement acceptBtnEle = driver.get().findElement(By.xpath("(//*[@class='Button CookieBanner__button Button--light'])[1]"));
        String acceptBtnText = acceptBtnEle.getText();
        softAssert.assertEquals(acceptBtnText, "Accept");
        WebElement rejectBtnEle = driver.get().findElement(By.xpath("(//*[@class='Button CookieBanner__button Button--light'])[2]"));
        String rejectBtnText = rejectBtnEle.getText();
        softAssert.assertEquals(rejectBtnText, "Reject");
        //verifying the cookie policy page is displayed on clicking the view policy button
        viewpBtnEle.click();
        WebElement cookiespage = driver.get().findElement(By.xpath("(//*[@class='Section Section--main'])[1]"));
        softAssert.assertEquals(cookiespage.isDisplayed(), "true");
        driver.get().manage().timeouts().pageLoadTimeout(Duration.ofSeconds(10));
        driver.get().manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        WebElement acceptCookiesButton = driver.get().findElement(By.xpath("//*[contains(text(), 'Accept')]"));
        //click the accept button
        acceptCookiesButton.click();
        //verifying the user is on the cookie page still
        softAssert.assertEquals(cookiespage.isDisplayed(), "true");
        //verifying the cookies value, name, domain which is accepted
        Set<Cookie> cookies = driver.get().manage().getCookies();
        System.out.println(cookies.size());
        WebDriverWait wait = new WebDriverWait(driver.get(), Duration.ofSeconds(20));
        for (Cookie cookie : cookies) {
            System.out.println("cookie name " + cookie.getName());
            System.out.println("cookie value " + cookie.getValue());
            //verifying the cookie value to be true
            softAssert.assertEquals(cookie.getValue(), "true");
            System.out.println("cookie domain " + cookie.getDomain());
            System.out.println("cookie path " + cookie.getPath());
            System.out.println("cookie expire " + cookie.getExpiry());
        }
    }
}
